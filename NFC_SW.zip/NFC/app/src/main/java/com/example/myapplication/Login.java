package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {
    TextView sign;
    DBHelper helper;
    SQLiteDatabase db;
    EditText edit_id,edit_pass;
    static String  id;


    public void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        helper = new DBHelper(this);
        try {
            db = helper.getWritableDatabase();
        } catch (SQLiteException ex) {
            db = helper.getReadableDatabase();
        }
        edit_id = (EditText) findViewById(R.id.editID);
        edit_pass = (EditText) findViewById(R.id.editPassword);

        sign=findViewById(R.id.open_signup);
        sign.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),Signup.class);
                startActivity(intent);
            }
        });


    }
    public void login(View target) {
        id =  edit_id.getText().toString();
        String pass = edit_pass.getText().toString();
        Cursor cursor;
        cursor = db.rawQuery("SELECT id, pass FROM user WHERE id='" + id + "';", null);

        while (cursor.moveToNext()) {
            String pass2 = cursor.getString(1);
            if(pass.equals(pass2))
            {
                Intent registerIntent = new Intent(Login.this, MainActivity.class);
                Login.this.startActivity(registerIntent);
                Toast.makeText(getApplicationContext(), "로그인 성공입니다.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
