package com.example.myapplication;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Signup extends AppCompatActivity {
    DBHelper helper;
    SQLiteDatabase db;
    EditText name1,id1,password,passwordcheck;
    Button check;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        helper = new DBHelper(this);
        try {
            db = helper.getWritableDatabase();
        } catch (SQLiteException ex) {
            db = helper.getReadableDatabase();
        }

        name1=findViewById(R.id.name_signup);
        id1=findViewById(R.id.id_signup);
        password=findViewById(R.id.password_signup);
        passwordcheck=findViewById(R.id.passwordcheck_signup);





        check=findViewById(R.id.check_button);
        check.setOnClickListener(v -> {

            if(password.getText().toString().equals(passwordcheck.getText().toString())){
                Toast.makeText(Signup.this,"일치",Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(Signup.this,"불일치",Toast.LENGTH_LONG).show();
            }
        });
        Button onclick4=findViewById(R.id.back_button);
        onclick4.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(),Login.class);
                startActivity(intent);
                finish();
            }
        });
    }
    public void enroll(View target) {
        String name = name1.getText().toString();
        String id = id1.getText().toString();
        String pass = password.getText().toString();
        String pass2 = passwordcheck.getText().toString();




        if(TextUtils.isEmpty(id) || TextUtils.isEmpty(pass) || TextUtils.isEmpty(name) || TextUtils.isEmpty(pass2))
        {

            Toast.makeText(Signup.this,"빈칸을 전부 채워주십시오.",Toast.LENGTH_SHORT).show();
        }else{

//            db.execSQL("INSERT INTO user VALUES (null, '" + name + "','" + id + "', '" + pass + "');");
            db.execSQL("INSERT INTO user VALUES (null, '" + id + "', '" + pass + "')");


            Toast.makeText(getApplicationContext(), "회원가입에 성공하셨습니다.", Toast.LENGTH_SHORT).show();

            id1.setText("");
            password.setText("");

            Intent registerIntent = new Intent(Signup.this, Login.class);
            Signup.this.startActivity(registerIntent);
        }
    }
}
